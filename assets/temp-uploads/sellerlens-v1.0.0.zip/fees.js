// SellerLens fee engine. Rates verified 2026-07-18 — see SPEC.md. Every rate is
// user-overridable in the UI; this file only supplies defaults.
const RATES_VERIFIED = '2026-07-18';

const PLATFORMS = {
  etsy: {
    name: 'Etsy',
    notes: 'Listing $0.20 · transaction 6.5% (price+shipping) · processing 3% + $0.25 (US)',
    fields: { listingFee: 0.20, transactionPct: 6.5, processingPct: 3.0, processingFlat: 0.25, offsiteAdsPct: 0 },
    calc(input, f) {
      const gross = input.price + input.shipBuyer;
      const transaction = gross * f.transactionPct / 100;
      const processing = gross * f.processingPct / 100 + f.processingFlat;
      const ads = gross * f.offsiteAdsPct / 100;
      return [
        ['Listing fee', f.listingFee],
        ['Transaction fee', transaction],
        ['Payment processing', processing],
        ...(ads > 0 ? [['Offsite ads', ads]] : []),
      ];
    },
  },
  ebay: {
    name: 'eBay',
    notes: 'Final value fee 13.25% on total (payment processing included) + $0.30/order. Category rates vary — edit to match yours.',
    fields: { fvfPct: 13.25, perOrder: 0.30 },
    calc(input, f) {
      const gross = input.price + input.shipBuyer;
      return [
        ['Final value fee', gross * f.fvfPct / 100],
        ['Per-order fee', f.perOrder],
      ];
    },
  },
  poshmark: {
    name: 'Poshmark',
    notes: 'Flat $2.95 under $15 · 20% commission at $15+. Buyer pays shipping by default.',
    fields: { flatUnder15: 2.95, pctOver: 20 },
    calc(input, f) {
      const fee = input.price < 15 ? f.flatUnder15 : input.price * f.pctOver / 100;
      return [['Poshmark commission', fee]];
    },
  },
  mercari: {
    name: 'Mercari',
    notes: 'Flat 10% selling fee (payment processing included).',
    fields: { sellingPct: 10 },
    calc(input, f) {
      return [['Selling fee', (input.price + input.shipBuyer) * f.sellingPct / 100]];
    },
  },
  depop: {
    name: 'Depop (US)',
    notes: '0% selling fee · payment processing 3.3% + $0.45.',
    fields: { processingPct: 3.3, processingFlat: 0.45 },
    calc(input, f) {
      const gross = input.price + input.shipBuyer;
      return [['Payment processing', gross * f.processingPct / 100 + f.processingFlat]];
    },
  },
};

// input: { price, shipBuyer, shipCost, cogs }
// overrides: partial fee-field overrides for the platform
function computeProfit(platformKey, input, overrides = {}) {
  const p = PLATFORMS[platformKey];
  const f = { ...p.fields, ...overrides };
  const lines = p.calc(input, f).map(([label, amt]) => [label, round2(amt)]);
  const totalFees = round2(lines.reduce((s, [, a]) => s + a, 0));
  const revenue = round2(input.price + input.shipBuyer);
  const costs = round2(totalFees + input.shipCost + input.cogs);
  const profit = round2(revenue - costs);
  const margin = revenue > 0 ? round2(profit / revenue * 100) : 0;
  const roi = input.cogs > 0 ? round2(profit / input.cogs * 100) : null;
  return { platform: p.name, lines, totalFees, revenue, profit, margin, roi,
           breakEven: breakEvenPrice(platformKey, input, overrides) };
}

// Smallest sale price where profit >= 0 (bisection — robust to Poshmark's step).
function breakEvenPrice(platformKey, input, overrides) {
  let lo = 0, hi = 10000;
  const profitAt = (price) => {
    const p = PLATFORMS[platformKey];
    const f = { ...p.fields, ...overrides };
    const inp = { ...input, price };
    const fees = p.calc(inp, f).reduce((s, [, a]) => s + a, 0);
    return (price + inp.shipBuyer) - fees - inp.shipCost - inp.cogs;
  };
  if (profitAt(hi) < 0) return null;
  for (let i = 0; i < 60; i++) {
    const mid = (lo + hi) / 2;
    if (profitAt(mid) >= 0) hi = mid; else lo = mid;
  }
  return Math.ceil(hi * 100) / 100;
}

function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

if (typeof module !== 'undefined') module.exports = { PLATFORMS, computeProfit, breakEvenPrice, RATES_VERIFIED };
