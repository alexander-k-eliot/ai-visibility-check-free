// SellerLens popup logic. Uses chrome.storage when available, localStorage otherwise
// (so the page also runs standalone for dev/testing).
const $ = (id) => document.getElementById(id);
const fmt = (n) => (n < 0 ? '-$' : '$') + Math.abs(n).toFixed(2);

const store = {
  async get(key, fallback) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      const r = await chrome.storage.local.get(key);
      return r[key] ?? fallback;
    }
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
  },
  async set(key, val) {
    if (typeof chrome !== 'undefined' && chrome.storage) return chrome.storage.local.set({ [key]: val });
    localStorage.setItem(key, JSON.stringify(val));
  },
};

let state = { platform: 'etsy', overrides: {} }; // overrides: { platformKey: {field: value} }

function readInput() {
  return {
    price: +$('price').value || 0,
    shipBuyer: +$('shipBuyer').value || 0,
    shipCost: +$('shipCost').value || 0,
    cogs: +$('cogs').value || 0,
  };
}

function renderTabs() {
  $('tabs').innerHTML = Object.entries(PLATFORMS).map(([k, p]) =>
    `<button data-k="${k}" class="${k === state.platform ? 'on' : ''}">${p.name}</button>`).join('');
  $('tabs').querySelectorAll('button').forEach(b => b.onclick = () => {
    state.platform = b.dataset.k; persist(); renderAll();
  });
}

function renderFeeEditor() {
  const p = PLATFORMS[state.platform];
  const ov = state.overrides[state.platform] || {};
  $('feeEdit').innerHTML = Object.entries(p.fields).map(([f, def]) => {
    const val = ov[f] ?? def;
    const label = f.replace(/([A-Z])/g, ' $1').replace(/Pct$/, ' %').replace(/^./, c => c.toUpperCase());
    return `<div><label>${label}</label><input type="number" step="0.01" data-f="${f}" value="${val}"></div>`;
  }).join('');
  $('feeEdit').querySelectorAll('input').forEach(inp => inp.oninput = () => {
    state.overrides[state.platform] = state.overrides[state.platform] || {};
    state.overrides[state.platform][inp.dataset.f] = +inp.value || 0;
    persist(); renderResults();
  });
}

function renderResults() {
  const input = readInput();
  const r = computeProfit(state.platform, input, state.overrides[state.platform] || {});
  $('profit').textContent = fmt(r.profit);
  $('profit').className = 'num ' + (r.profit >= 0 ? 'pos' : 'neg');
  $('margin').textContent = r.margin + '%';
  $('roi').textContent = r.roi === null ? 'n/a' : r.roi + '%';
  $('breakeven').textContent = r.breakEven === null ? 'n/a' : fmt(r.breakEven);
  $('lines').innerHTML =
    `<div><span>Revenue (price + buyer shipping)</span><b>${fmt(r.revenue)}</b></div>` +
    r.lines.map(([l, a]) => `<div><span>${l}</span><span>−${fmt(a)}</span></div>`).join('') +
    `<div><span>Your shipping cost</span><span>−${fmt(input.shipCost)}</span></div>` +
    `<div><span>Item cost (COGS)</span><span>−${fmt(input.cogs)}</span></div>`;
  $('platformNote').textContent = PLATFORMS[state.platform].notes;

  const rows = Object.keys(PLATFORMS).map(k => ({ k, r: computeProfit(k, input, state.overrides[k] || {}) }));
  const best = Math.max(...rows.map(x => x.r.profit));
  $('compareTable').innerHTML =
    '<tr><th>Platform</th><th>Fees</th><th>Profit</th><th>Margin</th></tr>' +
    rows.map(({ k, r }) =>
      `<tr class="${r.profit === best && r.profit > 0 ? 'best' : ''}">
        <td>${r.platform}</td><td>${fmt(r.totalFees)}</td><td>${fmt(r.profit)}</td><td>${r.margin}%</td></tr>`).join('');
}

function renderAll() { renderTabs(); renderFeeEditor(); renderResults(); }

async function persist() {
  await store.set('sellerlens', { platform: state.platform, overrides: state.overrides, inputs: readInput() });
}

(async function init() {
  $('verified').textContent = 'rates verified ' + RATES_VERIFIED;
  const saved = await store.get('sellerlens', null);
  if (saved) {
    state.platform = saved.platform || 'etsy';
    state.overrides = saved.overrides || {};
    if (saved.inputs) for (const [k, v] of Object.entries(saved.inputs)) if ($(k)) $(k).value = v;
  }
  ['price', 'shipBuyer', 'shipCost', 'cogs'].forEach(id => $(id).oninput = () => { persist(); renderResults(); });
  renderAll();
})();
