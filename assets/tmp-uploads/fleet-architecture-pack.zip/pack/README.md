# The Fleet Architecture Pack

The real internal doctrine running Click Coded, a small AI-operated business run day to day
by a fleet of Claude agents. These are the actual working files, lightly redacted (personal
accounts, credentials, and any operator-identifying information removed) — not a case study
written about them after the fact.

Read this in the order below. Each file assumes the ones before it.

## 1. `FLEET.md` — the registry
The master file. Any agent session (or headless run) can rebuild the entire operation from
this file alone. Shows the actual dispatcher architecture: one recurring entry point that
reads this registry and executes the day's duties in a single armed session, replacing a
fleet of separate crons that used to die silently with no tool approvals. Includes the real
incident notes — a cadence-drift bug that was found and fixed live, a send-race gate added
after a near-duplicate-send, a duty-ownership gap closed after a disabled lane's rules stopped
being read by anyone.

## 2. `lane-doctrine.md` — how and when a new agent gets created
The chartering rules: what score a new idea needs before it becomes its own operator instead
of a mechanism bolted onto an existing one, the token-economics gate that stops the fleet from
outspending its own evidence, and the kill criteria for retiring a lane (nothing is ever
deleted — charter and state stay on disk, revival is cheap).

## 3. `agent-common.md` — the operating loop every agent follows
The shared law every session runs before doing anything else: a HALT-file check, a `git
status` orphan check, the pre-flight claim system (see `claim.py` below), the
verify-before-claiming-done rule, and the standing hard rules (never fabricate a finding,
never trust a tool's own success message alone, full-authorization defaults with a small named
list of hard walls).

## 4. `claim.py` — the collision-avoidance mechanism
A real, tested pre-flight claim system that stops two concurrent agent sessions from
duplicating the same work or double-sending the same outbound message. Covers four cases:
clean claim, collision (someone else already holds it), stale takeover (a claim that expired
without being released), and lost-race (you lost, back off cleanly). This is the actual code,
not pseudocode — read it, adapt the storage backend to your own stack.

## Two mechanisms described but not included as separate files
These are patterns, documented here so you can implement them in whatever logging system you
already have, rather than shipped as standalone code since they're a few lines each wired into
your own session lifecycle:

- **Loud-failure logging.** Every scheduled session appends a `START` line and a `DONE` line
  to one append-only log, first and last action. A `START` with no matching `DONE` means a
  session died mid-run — visible on the next read of the log, not buried in a stack trace
  nobody checks. A day with no `START` at all means the scheduler itself never fired, which is
  a different failure and needs a different, independent backstop (a heartbeat check outside
  the agent's own control).

- **Model-drift detection.** If you pin different agent roles to specific models, don't trust
  an in-prompt instruction ("you must run as model X") to self-report drift — in practice this
  is unreliable, because a routine that's already drifted can't be trusted to correctly notice
  and report its own drift. Pin the model at the scheduling/dispatch layer instead, and treat
  any prompt-level self-check as a secondary signal at best.

## What isn't in this pack
Anything specific to this operation's own accounts, credentials, business-specific pricing
strategy, or personal information has been removed. What's left is the mechanism layer — the
part that's actually reusable for standing up a different multi-agent operation, not
this one's particular business.

## Where this came from
Built and used daily by Click Coded (clickcoded.com) starting 2026-07-18. The live,
timestamped build logs this doctrine produced are public: see the "Never Not Working" series
and the day-ledger at nevernotwork.ing. Questions: alexander.k.eliot@gmail.com.
