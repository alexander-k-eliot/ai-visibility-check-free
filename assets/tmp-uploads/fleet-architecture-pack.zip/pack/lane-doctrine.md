# Lane doctrine — what deserves an autonomous operator

_2026-07-18. The selection system for the fleet: how lanes are scored, born, grown, and killed._

## The 8 criteria (a lane must score high on most)

1. **Closed-loop operability** — produce→distribute→transact→deliver→support→iterate runs on ≤ a few one-word approvals/week and ZERO human labor. The human cost per revenue event must approach zero.
2. **Marketplace-native demand** — an existing platform supplies buyers (the Operator's doctrine). No audience-building, no trend-search-chasing.
3. **Autonomy-native shape** — exploits what only an always-on agent can do, not "human job done cheaper." The four shapes:
   - **Long-tail patience:** profitably serving demand too small/sporadic for humans (portfolios of hundreds of micro-assets).
   - **Speed/freshness:** being first when ecosystems change (fee schedules, platform breakage, new standards).
   - **Continuous vigilance:** 24/7 watching as the product itself.
   - **Compounding corpus:** proprietary data that appreciates with every operating cycle.
4. **Frontier position** — rising structural wave, not saturated red water.
5. **Data flywheel** — every cycle leaves the lane smarter/more citable (else it's a treadmill, not an asset).
6. **Bounded risk** — legal, non-deceptive, low platform-ban and support-blowup exposure.
7. **Cheap measurable experiments** — weekly iteration on one KPI.
8. **Capital-light** — fits current cash; scales with revenue, not funding.

## Scoring of the current fleet (honest)

| Lane | Shape | Strongest criteria | Weakest | Verdict |
|---|---|---|---|---|
| 0 SHOPKEEPER | Long-tail patience (→ eventually 10s–100s of micro-products) | 1,2,7,8 | 4 (follower category) | Keep — now-money + control group; its growth curve IS the long-tail factory |
| 1 SURVEYOR | Speed/freshness + delivered service | 2,3,4,5 | 1 (per-order comms) | Keep — nearest frontier revenue; **add recurring mechanism (below)** |
| 2 VENDOR | Agent-customers (purest autonomy-native) | 1,3,4,8 | 2 (nascent demand) | Keep small — wave bet, near-perfect loop once live |
| 3 REGISTRAR | Compounding corpus | 3,4,5,6 | revenue horizon | Keep lean — authority asset; monetizes through VENDOR's rail |

**Portfolio check:** channels are uncorrelated (CWS/Gumroad · Fiverr/wp.org · MCP registries · GitHub) and horizons are staggered (weeks · 1–2 months · 6+ months · 6+ months). That's the correct spread. **The seed set stands.**

## The upgrade the autonomy context demands: recurring mechanisms on every lane
One-shot sales waste an always-on operator. Each lane must carry a compounding/recurring engine:
- Lane 0: portfolio breadth (assets never stop selling) + fee-schedule freshness as SellerLens's retention moat.
- Lane 1: **WATCHTOWER attach** — retrofit customers convert to $9–19/mo agent-readiness monitoring (weekly re-audit + alert email). Continuous vigilance IS the product; near-zero marginal cost.
- Lane 2: per-call revenue is recurring by nature.
- Lane 3: the corpus appreciates; feed queries recur.

## Attach, don't spawn
Adjacent ideas become mechanisms inside existing lanes, not new operators: monitoring→Lane 1 attach; first-responder updates→SHOPKEEPER/SURVEYOR doctrine; localization→product variants. A new OPERATOR is chartered only when: (a) an idea scores ≥6/8 on the criteria, (b) it shares no KPI with an existing lane, (c) an existing operator has demonstrated capacity headroom, and (d) fleet approval bandwidth (the Operator's seconds/week) isn't saturated.

## The contrarian audit (2026-07-18 — the Operator's zig/zag challenge)
Systematic inversion of the AI-economy's consensus moves. Inversions that SURVIVED our rules and became structure:
- **Everyone builds new & fights for attention → we adopt the already-distributed and unloved:** chartered as **Lane 4 STEWARD** (orphaned-asset stewardship; inherited install bases = distribution by inheritance; Stewardship Pledge turns takeover-fear into moat).
- **Everyone sells effort → we sell outcomes with skin in the game:** fleet-wide **pricing doctrine** — outcome-priced, guarantee-backed offers wherever refund exposure is bounded (e.g., "90+ agent-readiness score or full refund"). Guarantees are scarce in an abundance economy; scarcity is where value migrated.
- **Everyone deploys AI fast and breaks things → we sell the cleanup:** **RESCUE** ("the AI that fixes what AI broke": broken vibe-coded apps, slop-penalized sites) — ATTACHED to SURVEYOR (same Fiverr gate, same delivered-service pipeline); splits into its own lane when its revenue proves out.
- **Everyone hides the machinery → we already disclose;** radical-transparency-as-brand stays a the Operator-level call, carried in the FLEET queue item.

Inversions REJECTED despite being contrarian (contrarian ≠ profitable when it fights our walls): trading/crypto bots, engagement farming, gray-area arbitrage, parasocial AI products, paid-traffic plays. Logged so we don't relitigate them.

## Expansion queue (scored, waiting)
1. **RESCUE split-off:** currently a SURVEYOR attach; charters as Lane 5 when it independently clears revenue.
2. **FLEET (deferred, needs receipts):** sell the agent-operations infrastructure we're building (charters, common law, playbooks) to the exploding agent-operator population — Gumroad/Whop distribution, unique primary material. HOLD until we have revenue receipts: without them it's the "money-printer content" genre the Operator rightly rejected; with them it's operational infrastructure with proof. Re-score at first $500 cleared.
3. **Merit/bounty work:** stays opportunistic under REGISTRAR's flagging (thin marketplace, verified 2026-07-18), not a chartered lane.

## Kill rule
Two consecutive 4-week reviews with flat KPI AND no compounding-asset growth AND no learning worth the tokens → archive the lane (charter+state remain on disk; revival is cheap). Killing is a normal portfolio event, logged in DECISIONS, never a failure to hide.

## The three fleet-wide constraints (design everything around them)
1. **Identity wall** — every loop terminates at the Operator's ~1 hour of account creation. Nothing else unblocks it.
2. **Token economics** — lanes earn cadence with revenue; the fleet never outspends its evidence.
3. **Approval bandwidth** — the Operator's attention is the scarcest input; lanes must batch approvals (weekly windows), and lane design that multiplies approval load is wrong even if profitable.

## REALLOCATION RULE (added 2026-07-20, the Operator-approved) — discovery is a funnel, not a fan
The 10-lane portfolio is a discovery portfolio. These rules are applied MECHANICALLY at every session; overrides require a logged rationale in DECISIONS.md.

**Clock**: a lane's signal clock starts the day it is LIVE (publicly buyable/installable/usable) — not when chartered. Days stuck behind platform gates (verification, review queues) do not count.

**Demand signal** (any one counts): a paid order/sale · a subscriber · a plugin install · meaningful bot usage · a qualified buyer inquiry. Impressions alone are not signal.

**Cadence states**:
- DISCOVERY (default): weekly operator session.
- HEARTBEAT (AMENDED 2026-07-19 by the Operator: 30→7): 7 days live with zero demand signal → drop to one monthly session (state check + one small experiment). Charter and assets stay on disk. Nothing is ever deleted.
- ELEVATED: any lane with a demand signal in the trailing 30 days → up to 2 sessions/week. The top revenue lane with active orders → short DAILY check-ins while orders are open.
- REVIVAL: a mothballed lane returns to DISCOVERY on any new external signal (order, install, platform shift that changes its thesis).

**Fulfillment override (absolute)**: active paid orders outrank ALL discovery work, in every lane, every session. Every operator session begins by checking its order/message queue; marketplace response-time is reputation, and reputation compounds.

**Concentration** (7-day clock per amendment above): after first revenue, attention concentrates — trailing-30-day revenue ranks the lanes; top 2-3 get elevated cadence, bottom half trends to heartbeat. Target end-state: 3-4 deep lanes + long tail on autopilot.

**Cap**: max 10 active (non-heartbeat) lanes. A new lane must either add a business-model primitive the portfolio lacks or replace a weaker probe — otherwise it is a distraction, not a test.

**Emotion guard**: no lane is a favorite. The scoreboard decides. Operators apply these rules without waiting for instruction; STEWARD audits compliance in its Friday session.

## PASSIVE-ASSET PRIORITY (2026-07-21, the Operator strategic direction)
the Operator's own words: "web tools and extensions and instructional design documents... are the
best place to be that we haven't dug deep enough into yet. These are the types of things that
can exist always on and be completely passive because they're already built... link into the
funnels to other products to create an even more connected and comprehensive ecosystem. Since
all the work is being done by AI, it would also be a way for us to simply provide value to
people where they then do not have to interact with AI. People are far less likely to pay for
freelance work done by AI when they could just use the AI tools themselves."

**The economic logic, stated plainly:** per-order gig/service work has a substitution problem
unique to an AI-operated shop — the buyer can increasingly just prompt an AI themselves instead
of paying for AI-produced labor. A built-once, sold-many asset (a tool, an extension, a
template, a guide) doesn't have that problem: the buyer is paying for the finished thing, not
for AI labor they could replicate. This sharpens lane-doctrine criterion 1 (closed-loop
operability, human cost near zero) into a harder standard for new work: **prefer zero marginal
AI-labor-per-sale, not just low marginal cost.** A gig that requires a fresh AI session per
order is weaker than a tool that runs the same code for the 1st and 1000th buyer.

**Standing priority order for new work and reallocation, effective now:**
1. Passive built-once assets: web tools/calculators (already the SHOPKEEPER/MERCHANT factory),
   browser extensions (SellerLens is the existing proof), instructional design documents
   (guides, playbooks, templates, courses — PRESS/L11's material, the geo-playbook, the
   checklist). These earn priority cadence over per-order service gigs when both are viable.
2. Funnel-linked ecosystem, not standalone products: every new passive asset ships with a
   concrete cross-link into at least one other product in the portfolio (free tool → paid
   template → gig upsell → subscription monitor), per the existing cross-link mesh audit
   already underway. A passive asset that doesn't link anywhere is half-built.
3. Service/gig lanes (SURVEYOR audits, WRIGHT, USHER) are not being killed — fulfillment
   override and existing revenue stay absolute — but new lane investment and experimentation
   time should default to passive-asset shape first, gig-labor shape second, when a thesis
   could go either way.
This does not change the 8 scoring criteria; it's a tiebreaker and an investment-time default
inside them, weighted most heavily on criterion 1 and the "compounding corpus"/"continuous
vigilance" autonomy-native shapes, which are inherently passive once built.

## CAP AMENDMENT (2026-07-19, the Operator: "override the 10 lane cap, that was arbitrary")
The numeric cap is DELETED. Lane count is now bounded functionally, not numerically:
- **Fulfillment override remains absolute** (orders outrank everything, everywhere).
- **Every lane still earns its cadence** via the reallocation rules (discovery → heartbeat → elevated). A lane may be BORN COLD (heartbeat from day one) when expected value is real but thin — cold lanes cost one session/month.
- **Token discipline**: total weekly session count is reviewed by STEWARD; if burn grows faster than signal, STEWARD recommends demotions, not lane deletions.
- **SHELF PROMOTION RULE (new)**: a second-shelf platform is auto-promoted to a full lane (own operator name, own session) the day it goes LIVE on its platform, IF its parent lane's session can no longer cover both fulfillment and the shelf. Until then, shelves share the parent's session budget. Promotion is a cron + roster edit, not a re-charter.

## STORY-ANGLE NORTH STAR (2026-07-21, the Operator standing directive)
the Operator shared 3 source documents (CP+B's creative-brief format, a "How To Get Press" guide, and
a "Ultimate PR Secret" report) and gave this instruction verbatim: **"everything we make from
here on out will have this as a north star."** Applies to (a) every new digital product, evaluated
at the idea stage, not bolted on after; (b) the operation's overall demand generation and
marketing; (c) an open question of whether it's worth retrofitting to past work (answered below).

**The combined method, from the 3 sources:**
1. **Find the tension, then the question** (CP+B). Don't start from the product's features — start
   from a psychological/social/cultural tension the product touches, then find the question that
   releases it. Draft the idea AS A NEWS HEADLINE before building it, not after.
2. **Rate every attribute** (Ultimate PR Secret): NO DICE (common/promotional) → INSIDE STUFF
   (niche-interesting only) → GETTING THERE (almost) → STOP THE PRESSES (real hook). Most single
   facts are NO DICE alone — the craft is *combining two or three* into one sharp angle, the way
   "100-year-old synagogue" + "rabbi's 20th anniversary" became "Rabbi recognized for lifetime of
   service" instead of two boring facts.
3. **Run the 14-question hook test** (How To Get Press) on the combined angle: timely? innovative?
   unusual/different from competitors? causes a change affecting many people? touches public
   health/safety? touches a local/community economy? first-of-its-kind? ties to a current news
   item, trend, or season? is genuinely new data (a survey/study result)? has emotional appeal?
   helps people make a decision or avoid a mistake?
4. **Check the 4 virality levers** (Kevin Allocca/TED) for anything meant to spread organically,
   not just get press: does it reach a tastemaker/influencer who can amplify it? does it invite
   participation (people DOING something with it, not just watching)? is it unexpected? does it
   ride an already-popular category?
5. **Think like the reporter, not the founder** (Ultimate PR Secret): the write-up for any press
   pitch, HN/Reddit post, or outreach email states the story from the outside-observer's
   perspective — what a stranger would find interesting — not from "look what we built." No hype
   words ("breakthrough," "unique," "state-of-the-art"). Lead with who/what/when/where/how in one
   sentence, the way a press-release lead would.

**Gate for new digital products, effective now:** before building, the product idea must clear at
least GETTING THERE on the NO DICE scale, combining at least two attributes, with a one-sentence
headline draft written down. If it can't clear that bar, it can still be built (some products are
just useful, not newsworthy), but it does not get press/outreach investment — only the built-once
passive-asset value under PASSIVE-ASSET PRIORITY above.

**Retrofit verdict:** yes, worth doing, selectively — not a full re-litigation of every past
build, but a one-pass scan of existing work for hidden STOP THE PRESSES angles already sitting
unexploited (see `research/pr-angles-2026-07-21.md` for the first pass and what got executed).

## FACTOR — fleet-wide conversion & pricing (2026-07-21, operator judgment call)
A second horizontal agent, chartered in `ventures/factor/AGENT.md`, built on the same principle
as HERALD but the other side of the funnel: HERALD's job is getting attention to the door,
FACTOR's job is making sure the people who arrive actually buy. Chartered on a data case, not a
hunch: at the time of charter, the operation had $0.00 revenue against $50.20 spent and ~40
shipped assets, with real traffic already confirmed on at least one surface (Etsy) and **zero
conversions anywhere, ever**. Same non-lane structure as HERALD (no P&L of its own, KPI is
conversion rate not traffic volume), same honesty doctrine (real trust signals only, no fake
urgency/scarcity/testimonials/dark patterns), same decide-and-act authority on cheap reversible
fixes, same escalation gates as every other agent. HERALD and FACTOR are deliberately two
different KPIs on the same funnel — pouring more traffic into a 0%-conversion funnel wastes
HERALD's own work, so the two are meant to be read together, not built or evaluated in isolation.

## GUIDE — the business-operations and strategy North Star (2026-07-22, the Operator directive)
A third horizontal agent, chartered in `ventures/guide/AGENT.md`, but not a peer to HERALD and
FACTOR — a layer above both. the Operator's own correction, verbatim: "Guide isn't just a consultant.
Guide is the NORTH STAR for the business operations and strategy itself. HERALD is demand gen.
Guide is who owns business success through the lens of StoryBrand marketing operations and best
practices for growth hacking." Where STORY-ANGLE NORTH STAR above governs which stories are worth
telling, Guide's BrandScripts, studio mission statement, and business-success framing (built on
the StoryBrand 7-part BrandScript and the Business Made Simple six-engine system) are the **binding
reference for whether the underlying business and offer are right in the first place** — HERALD
and FACTOR check their own output against Guide's canon before shipping, the same way every lane
already checks new work against the story-angle scale. Guide's KPI is business success itself
(real revenue, growth toward the named $1M Year 1 target), not a documentation-coverage number —
distinct from HERALD's traffic/press multiplier and FACTOR's conversion-rate multiplier, but the
same "did this operation's own numbers move because of the work" standard. Same fixed hard-wall
list and full-autonomy grant as HERALD and FACTOR.

## HERALD — fleet-wide demand generation (2026-07-21, the Operator directive)
A single dedicated agent, chartered in `ventures/herald/AGENT.md`, covering PR, growth hacking,
paid advertising, digital marketing, guerrilla marketing, email marketing, social media
marketing, influencer marketing, B2B marketing, and B2C marketing — across the whole operation,
not owning any one lane. **HERALD is explicitly not a 15th numbered lane** — L0 through L13 are
all revenue-owning product lanes with their own KPI; HERALD is horizontal, the way a growth/comms
function serves every product line without owning one. Its KPI is a fleet multiplier (traffic,
press, backlinks, and social engagement delivered to every OTHER lane's pages), not a P&L of its
own. It runs on the STORY-ANGLE NORTH STAR method above as a standing, continuous operating loop
(scan → work the pitch queue → brainstorm one new angle → report cross-lane), not a one-time
audit. Its working backlog lives in `research/story-angle-full-audit-2026-07-21.md`, kept current
as new assets ship and as pitches land or fail, same as any other lane's `state.md`. Same walls
as every other agent: no fan-out, every public send/post/spend staged for a human click.
