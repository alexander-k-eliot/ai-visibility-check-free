#!/usr/bin/env python3
"""Work claims — stop concurrent sessions from doing the same job twice.

Built 2026-07-26 after the fourth same-window collision in one day: four sessions
ran the identical "engineer for STOP THE PRESSES" brief within minutes of each
other, and earlier the same day two sessions independently executed
"Hey ChatGPT, Am I Real?" to two different live URLs.

Why the existing rule was not enough. `agent-common.md` already says to check for
concurrent work before starting something strategic, and every one of those
sessions could have followed it perfectly and still collided: the only shared
signal was a state.md entry or a commit, both of which get written *after* the
work is done. You cannot read a record that does not exist yet. This flips the
order — a session writes down what it is about to do, before it does it.

The medium is the local filesystem, not git, because every fleet session runs on
this same Mac in this same directory, and a local file is visible to a concurrent
session instantly while a commit is not. Claims are therefore deliberately NOT
committed (see ops/claims/README.md for the honest limitation this implies).

    python3 scripts/claim.py take viral-brief "STOP THE PRESSES ideation" --by HERALD
    python3 scripts/claim.py list
    python3 scripts/claim.py check viral-brief
    python3 scripts/claim.py beat viral-brief          # still working, extend it
    python3 scripts/claim.py release viral-brief

`take` exits 0 if the claim is yours to work, and 3 if someone else holds it —
so a caller can branch on the exit code without parsing anything:

    python3 scripts/claim.py take viral-brief "..." --by HERALD || exit 0

Claims expire. A session that crashes mid-run (which is exactly what happened
here) must not hold a lane hostage forever, so a claim older than its TTL with no
heartbeat is stale and can be taken over. Takeovers are recorded on the new
claim, not silently overwritten, because "the last session died here" is
information worth keeping.
"""
import argparse
import json
import os
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

CLAIMS = Path(__file__).resolve().parent.parent / "ops" / "claims"
DEFAULT_TTL_MIN = 45


def now():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def parse(ts):
    return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def session_id():
    """Best available identity. No env var is guaranteed, so fall back to the pid."""
    for var in ("CLAUDE_SESSION_ID", "CLAUDE_CODE_SESSION_ID"):
        if os.environ.get(var):
            return os.environ[var][:12]
    return "pid-%d" % os.getpid()


def path_for(slug):
    return CLAIMS / ("%s.json" % slug)


def read(slug):
    try:
        return json.loads(path_for(slug).read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def is_stale(claim):
    last = parse(claim.get("heartbeat") or claim["started"])
    return now() > last + timedelta(minutes=claim.get("ttl_minutes", DEFAULT_TTL_MIN))


def write_atomic(slug, claim):
    """O_EXCL is the whole lock. Two sessions racing here, one of them loses."""
    CLAIMS.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(path_for(slug)), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    with os.fdopen(fd, "w") as f:
        json.dump(claim, f, indent=2)
        f.write("\n")


def cmd_take(a):
    existing = read(a.slug)
    took_over = None

    if existing:
        if not is_stale(existing):
            held = parse(existing["heartbeat"] or existing["started"])
            mins = int((now() - held).total_seconds() // 60)
            print("HELD by %s (%s) since %s, %dm ago: %s"
                  % (existing["by"], existing["session"], existing["started"], mins,
                     existing["task"]))
            print("Do something else, or wait for it to be released or go stale "
                  "(ttl %dm)." % existing.get("ttl_minutes", DEFAULT_TTL_MIN))
            return 3
        took_over = {k: existing[k] for k in ("by", "session", "started", "task")}
        path_for(a.slug).unlink()
        print("STALE claim by %s from %s taken over (no heartbeat inside ttl)."
              % (existing["by"], existing["started"]))

    claim = {
        "slug": a.slug,
        "task": a.task,
        "by": a.by,
        "session": session_id(),
        "pid": os.getpid(),
        "started": iso(now()),
        "heartbeat": iso(now()),
        "ttl_minutes": a.ttl,
    }
    if took_over:
        claim["took_over_from"] = took_over

    try:
        write_atomic(a.slug, claim)
    except FileExistsError:
        # Lost the race between the read above and the create. The other session
        # got there first, which is the correct outcome, not an error.
        other = read(a.slug) or {}
        print("HELD by %s — lost the race, they claimed it first." % other.get("by", "?"))
        return 3

    print("CLAIMED %s by %s (%s), ttl %dm" % (a.slug, a.by, claim["session"], a.ttl))
    return 0


def cmd_beat(a):
    claim = read(a.slug)
    if not claim:
        print("No claim on %s." % a.slug)
        return 1
    claim["heartbeat"] = iso(now())
    path_for(a.slug).write_text(json.dumps(claim, indent=2) + "\n")
    print("HEARTBEAT %s (%s)" % (a.slug, claim["heartbeat"]))
    return 0


def cmd_release(a):
    claim = read(a.slug)
    if not claim:
        print("No claim on %s, nothing to release." % a.slug)
        return 0
    path_for(a.slug).unlink()
    held = int((now() - parse(claim["started"])).total_seconds() // 60)
    print("RELEASED %s (held %dm by %s)" % (a.slug, held, claim["by"]))
    return 0


def cmd_check(a):
    claim = read(a.slug)
    if not claim:
        print("OPEN — no claim on %s." % a.slug)
        return 0
    state = "STALE" if is_stale(claim) else "HELD"
    print("%s by %s (%s) since %s: %s"
          % (state, claim["by"], claim["session"], claim["started"], claim["task"]))
    return 0 if state == "STALE" else 3


def cmd_list(a):
    if not CLAIMS.exists() or not any(CLAIMS.glob("*.json")):
        print("No active claims.")
        return 0
    for f in sorted(CLAIMS.glob("*.json")):
        claim = read(f.stem)
        if not claim:
            continue
        state = "STALE" if is_stale(claim) else "HELD "
        held = int((now() - parse(claim["started"])).total_seconds() // 60)
        print("%s %-22s %-10s %4dm  %s" % (state, claim["slug"], claim["by"], held,
                                           claim["task"]))
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("take", help="claim a lane before starting work")
    t.add_argument("slug")
    t.add_argument("task")
    t.add_argument("--by", default="unknown", help="agent name, e.g. HERALD")
    t.add_argument("--ttl", type=int, default=DEFAULT_TTL_MIN)
    t.set_defaults(fn=cmd_take)

    for name, fn, helptext in (("release", cmd_release, "give the lane back"),
                               ("check", cmd_check, "is this lane free?"),
                               ("beat", cmd_beat, "still working, extend the ttl")):
        p = sub.add_parser(name, help=helptext)
        p.add_argument("slug")
        p.set_defaults(fn=fn)

    p = sub.add_parser("list", help="show every active claim")
    p.set_defaults(fn=cmd_list)

    a = ap.parse_args()
    sys.exit(a.fn(a))


if __name__ == "__main__":
    main()
