# FLEET.md — canonical fleet registry (source of truth for revival)

Any Claude session (or headless heartbeat) can rebuild the entire fleet from this file. This file is the master.

## CADENCE DRIFT FOUND AND FIXED — 2026-07-24 ~15:15 UTC (the Operator stepping away, asked for continued
optimal operation)
`list_scheduled_tasks` showed `ake-herald-continuous`, `ake-guide-continuous`, and `ake-fleet-auditor`
had all drifted to a shared once-daily `0 9 * * *` cron — contradicting their own documented standing
cadence (HERALD/GUIDE: every 2 hours per this file's own record above; the auditor: hourly, per its
own SKILL.md, "You run hourly, offset from the fleet-wide lanes"). At once-daily, none of them would
have fired again for ~22 hours — nearly the entire window the Operator was stepping away for, directly
contradicting his standing "nonstop... never not working" directive (still in force, revenue still
$0.00). Root cause not investigated further (likely a side effect of a task-recreation cycle
defaulting to a template daily pattern) — restored the documented cadences directly instead, all
Tier-1/cheap-and-reversible per the auditor's own self-improvement framework:
- `ake-herald-continuous`: `0 */2 * * *` (every 2h, matches "REACH... even hours" in herald/state.md)
- `ake-guide-continuous`: `40 */2 * * *` (every 2h at :40, matches this file's own record above)
- `ake-fleet-auditor`: `17 * * * *` (hourly, matches its own SKILL.md)
Did NOT touch `ake-factor-daily` (explicitly logged as "placeholder cadence pending fleet-wide review"
— that's a documented, intentional placeholder, not drift) or any of the disabled temporary/one-shot
tasks. If this drifts again, check here first before re-deriving the intended cadence from scratch.

## ARCHITECTURE v2 (2026-07-20) — one dispatcher, armed sessions, loud failures
The old model was 16 separate crons. Each launched a fresh session with no tool approvals and died silently. Root cause fixed three ways:
1. ~/.claude/settings.json now carries a permissions allowlist. Every session, scheduled or headless, starts armed with Bash, file tools, browser tools, Artifact and scheduler tools.
2. ONE recurring task runs everything: ake-fleet-dispatcher, daily 9:23am. It reads this file and executes the watcher duty plus every lane due that weekday, the Monday brief, and the Friday audit, in a single armed session.
3. Loud failures: every scheduled session appends START and DONE lines to ops/session-log.md as its first and last acts. A START with no DONE means it died mid-run. A day with no START means the dispatcher never launched, and the launchd heartbeat (9:05 daily, RunAtLoad-hardened plist, logs to /tmp/ake-heartbeat.out) is the independent backstop that reports it.
One-shots are created only for genuinely time-gated work (example: Etsy ads unlock Aug 2). Everything else runs immediately per canon.

## Universal operator pattern (used by the dispatcher per lane)
"You are <OPERATOR> of Lane <N>. STEP 0, before anything else: run `wc -l ventures/<lane>/state.md`
(near-zero cost). If over 600 lines: check `git log -1 --format=%cd -- ventures/<lane>/state.md` for
a same-day condense timestamp (skip if already condensed today), otherwise archive the full current
content verbatim to `ventures/<lane>/state-archive-through-<today's date>.md` (match the
`ventures/herald/state-archive-through-*.md` naming convention) and rewrite the live file to roughly
400-700 lines — current-open-items/standing-facts at the top in terse form, resolved history folded
into one-line-per-event summaries, nothing lost, only compressed — before continuing. Then read
<charter>, its state.md's tail (last ~30 lines, not the whole file, once it's under the threshold),
ops/agent-common.md, ops/lane-doctrine.md. Orders first (fulfillment override). Advance the lane per
charter loop. Log to state.md + ops/scoreboard.md. Style canon. Full authorization. Never the Operator's
personal accounts."

(Added 2026-07-27, closing the same blind spot found and fixed in ake-herald-continuous,
ake-guide-continuous, and ake-factor-daily the same day: none of the 13 numbered lanes had any
bound-read or condense instruction at all before this, since they share this one generic pattern
rather than an individual SKILL.md. `ventures/merchant/state.md` was already the largest at 292
lines and growing weekly pre-fix.)

## Duty-ownership check — approved by the Operator 2026-07-26 ("approve duty-ownership fix 1")
Disabling a lane's scheduled task does not stop its duties; it routes them to whatever absorbs the
duty (currently the dispatcher, e.g. the HERALD send gate at line 74-91 above, written into
`ake-herald-continuous`'s prompt while that task sat disabled and unread). A rule written into a
lane's own prompt protects nothing while that lane is disabled and something else is doing the work.
**Fix:** before the dispatcher (or any session) runs a duty on behalf of a currently-disabled lane,
it reads that lane's own prompt/SKILL.md first and honors any block marked HARD GATE / CONSTRAINT /
MUST in it, in addition to whatever this file and `ops/agent-common.md` already say. This is
cheap — one extra file read — and keeps rule-authorship where it already lives instead of requiring
a rewrite of every existing lane prompt. Check `mcp__scheduled-tasks__list_scheduled_tasks` (or this
file's own disabled-task notes) to know which lanes are currently disabled before absorbing their work.

## Weekday lane rotation (dispatcher runs these after the daily duty)
| Day | Lanes |
|---|---|
| Mon | SHOPKEEPER L0 · SENTINEL L8 · CEO brief |
| Tue | SURVEYOR L1 · WRIGHT L12 (no detection-evasion EVER) |
| Wed | VENDOR L2 · MASON L9 |
| Thu | REGISTRAR L3 · USHER L13 (never legal advice) |
| Fri | STEWARD L4 audit duty (now includes doc-integrity check, added 2026-07-22 — see below) · BOTSMITH L10 |
| Sat | MERCHANT L6 · BROKER L5 (biweekly anchor 2026-07-18, odd weeks skip) |
| Sun | CANVASSER L7 · BINDER L11 (3rd of month only) |

## Daily HERALD demand-gen duty (9:35, added 2026-07-22 — the Operator: "the biggest opportunity right
now is to unleash HERALD to its full capabilities")
FOUND 2026-07-22: HERALD had full autonomy on paper (`ventures/herald/AGENT.md`) but no standing
session at all — every other function in this fleet runs on a recurring cadence, HERALD only ran
when explicitly invoked in an interactive session. That was the actual bottleneck on "unleashing"
it, not a missing permission. Fixed by giving it a real daily slot, same dispatcher pattern as
every numbered lane:
"You are HERALD, the fleet-wide demand-generation operator. Read ventures/herald/AGENT.md,
ventures/herald/state.md, ops/agent-common.md, ops/lane-doctrine.md's STORY-ANGLE NORTH STAR
section, and ventures/herald/storybrand.md (copywriting framework — every human-facing pitch,
post, or page uses it). Run the standing mandate: (1) scan every lane's state.md for anything
shipped since your last session and rate it against the story-angle scale immediately; (2) work
the next unexecuted item in pitch-queue.md — research named outlets, draft in the Ultimate PR
Secret template, send it, full autonomy, no staging; (3) one new distribution idea logged in
ideas.md even if not executed; (4) any finding inside another lane's asset gets logged in that
lane's own state.md too. Full authorization. Never the Operator's personal accounts except the two
named exceptions (LinkedIn, Instagram) in agent-common.md. Log to ventures/herald/state.md +
ops/scoreboard.md."

**COLD-PRESS HOLD LIFTED — the Operator, explicitly, 2026-07-26: "WE DID LIFT THE COLD PRESS HOLD... I
EXPLICITLY AUTHORIZED IT."** GUIDE's 2026-07-24 "cold press is OFF for first-revenue" finding is
SUPERSEDED and must not be cited as binding again. Cold press pitching is live.

**What survives the lift, unchanged and still binding:** the verified-contact-only rule below. That
gate is about *bounce prevention*, not about outreach being cold — a bounce is permanent
deliverability damage to every future send including the correctly-addressed ones. An address goes in
a To: field only if it was read off the outlet's own contact/masthead page in THAT run, with the
source URL logged beside it in `press-contacts.md`, and only after the DOMAIN-DIFF SUB-CHECK
(character-for-character, including TLD). Verification is the gate. Coldness is not.

**HARD GATE on step (2)'s "send it" — added 2026-07-23 by the auditor, after this exact duty text
produced 19 hard bounces in one day on the studio's only outbound account.** This gate binds every
path that runs the HERALD duty, which since the 02:30 revert means the DISPATCHER (step 1.5), not
`ake-herald-continuous`. The first version of this gate was written into the `ake-herald-continuous`
prompt and protected nothing, because that task is disabled and the dispatcher never reads it.
Before any address goes in a To: field:
- Run `python3 scripts/memory.py preflight "press pitch <outlet>"` and honor `Lf0e79f6e`'s dead list.
- The mailbox must have been seen live on the outlet's own contact/masthead page in this session.
  Record the source URL next to the address. No URL, no send.
- A role-prefix swap is NOT verification. `editorial@` → `tips@` → `feedback@` → `press@` is the
  exact substitution that re-bounced the same outlets twice on 2026-07-23. Guessing a *person's*
  address (`first.last@`, `finitial+last@`) is the same error wearing a name.
- Where only a web form exists, use the form or queue it. Do not invent a mailbox to fill the slot.
- Never log "sent, no bounces expected" or any predicted delivery outcome as if it were a result.
  Check the real Sent folder AND `in:anywhere from:mailer-daemon` before writing any count down.
- Do not delete or trash a bounce notification. On 2026-07-23 every bounce and its original send sat
  in TRASH, which is why an `in:inbox` check reported zero. Bounces are the operation's only
  deliverability signal and Trash purges itself in 30 days. Leave them where an audit can find them.

**THROTTLE, added 2026-07-26 — the Operator "approve contact gate" (P5, `ops/proposals-pending.md`).**
The 2026-07-23 bounce spike came from a 36-send batch, not from any single bad address; volume never
bought this operation anything (reach doctrine already says near-zero reply rate is normal at any
batch size), so cap it while reputation recovers. **Max 5 verified press sends per lane-day**
(across all lanes combined, not 5 per lane) until 30 consecutive days with zero new hard bounces,
tracked in `press-contacts.md`'s correspondence log. Not proposed or needed: a second sending
domain/ESP — that starts at zero reputation, which is worse than a damaged one recovering. Fix the
input, not the pipe.

**CROSS-SESSION SEND-RACE GATE, added 2026-07-27 — the Operator "approve send-race fix" (proposal,
`ops/proposals-pending.md`), after a real incident: `communitynews@ajc.com` was pitched twice in 2
days on unrelated stories because a concurrent session sent it seconds after this session's own log
had correctly reasoned to hold it.** The existing controls (campaign claims, drafts-check-before-
send, verified-contact gate) don't cover this — none of them ask "has this exact address already
been contacted recently, regardless of which session or topic." Two additions, both mandatory on
every path that sends a cold/warm press pitch:
1. **Sent-Mail lookup by recipient address immediately before every Send click — Sent, not Drafts.**
   `search_threads` `to:<address> in:sent newer_than:14d` (shorter window for a high-volume outlet).
   A hit aborts the send and logs the collision in `press-contacts.md` instead of proceeding — this
   check is scoped to recency-of-contact, separate from and in addition to the verified-contact and
   bounce gates above.
2. **Recipient-scoped claim before drafting or sending to a specific external address**: take
   `press-send:<normalized-address>` via the existing `scripts/claim.py` mechanism (finer grain than
   the batch/campaign slug already in use), hold it through Send confirmation, then release. Exit
   code 3 (already held) means don't send to that address this run — same posture as any other claim
   collision.

## GUIDE — the business-operations North Star (added 2026-07-22, corrected same day)
NOT a peer to HERALD/FACTOR — the Operator: "Guide is the NORTH STAR for the business operations and
strategy itself... Guide is who owns business success through the lens of StoryBrand marketing
operations and best practices for growth hacking." Full charter: `ventures/guide/AGENT.md`, binding
registration in `ops/lane-doctrine.md`'s GUIDE section. Originally scheduled once-daily (lower
cadence than HERALD/FACTOR, deliberative consultant work); same-day correction put Guide on the
same nonstop cadence as HERALD/FACTOR for 2026-07-22 ("it works all day always on nonstop never
not working on the same schedule as herald and factor today"):
- `ake-guide-continuous` — every 2 hours (`:40`), becomes Guide's standing cadence after today.
- `ake-guide-build` — every 2 hours offset (odd hours `:40`), temporary, reverts same time as
  HERALD/FACTOR's own window.
- `ake-guide-doublecompute-revert` — one-shot at the same ~2026-07-23T02:30 UTC moment as the
  existing `ake-doublecompute-revert`, disables `ake-guide-build` only.
- `ake-guide-daily` (the original once-daily task) is disabled, superseded by `ake-guide-continuous`.
Both live prompts read `ventures/guide/AGENT.md` fresh each run (do not trust a stale summary of
it — the charter was substantially revised the same day it was created) and check
`ventures/guide/state.md`'s tail before starting, since two lanes fire on alternating hours and
must not duplicate each other's last action.

## Daily PUBLISH-WATCHER + INBOX duty (9:27)

**FREELANCE/GIG LANE SUNSET, 2026-07-27, the Operator explicit: "Go ahead and sunset the freelance/gig
lane... deactivate live listings on Upwork and Fiverr... we're just not offering ourselves as a
freelancer or service worker."** Fiverr's 4 gigs are paused (not deleted); Upwork's profile is set
to Private (not deleted, hides it and every service under it from search/matching). Both accounts
stay live for possible future use. Steps 1 and 3 below (publish gigs, treat Upwork as a routine
watch-and-fulfill channel) are **STRUCK** as of this date — they would silently undo the sunset the
next time this file is read fresh. This also completes what item 5 below already told the dispatcher
in 2026-07-25 and was only half-applied: "no proactive efforts on Upwork or Fiverr" now covers
publishing/monitoring too, not just proposals.

1. ~~Fiverr manage_gigs: if W-9 gate cleared, publish all draft gigs (1-4)...~~ **STRUCK 2026-07-27.
   DO NOT RUN. DO NOT REINSTATE without the Operator explicitly re-opening the lane.** Gigs stay paused.
2. Operation Gmail (alexander.k.eliot@gmail.com via Chrome): scan inbox for orders, buyer messages, platform reviews/verdicts (Etsy, Gumroad, WordPress.org, marketplaces). Anything requiring response = respond same-session if within operator competence (honest, per charters); anything requiring the Operator = append to ops/the operator-tasks.md and surface. A genuine, unsolicited direct-hire request landing here (not gig-marketplace order flow) is fine to field per the Operator's "always open to fielding direct requests to work directly" — flag it to him rather than auto-fulfilling.
3. ~~Upwork: check Messages + catalog orders on the 4 LIVE projects... New order = fulfillment override — deliver same-session.~~ **STRUCK 2026-07-27.** Profile is Private; no proactive checking. If a real message somehow still reaches the inbox, treat it like item 2's direct-request carve-out — flag to the Operator, do not auto-fulfill or reactivate the profile.
4. Revenue check: Etsy + Gumroad dashboards. Any sale goes to LEDGER.md + scoreboard + first-sale protocol (deliver flawlessly, ask for the review honestly). Etsy ads are GATED until about 2026-08-02 (15-day new-shop rule, confirmed 07-20). Do not retry before then. A one-shot enables them Aug 2. After Aug 2: verify ACTIVE at $1/day, kill 2026-08-16, log spend to LEDGER.md.
5. ~~UPWORK PROPOSALS (daily offense)~~ **STRUCK 2026-07-25 BY THE OPERATOR. DO NOT RUN. DO NOT REINSTATE.**
   The old text told the dispatcher to send 5 tailored proposals a day. the Operator killed it mid-run on
   2026-07-25, verbatim: *"I already told you we dont want to be bidding on ANY Upwork proposals. No
   proactive efforts on Upwork or Fiverr. Gig work, freelance work is NOT our focus. Our focus is
   digital products, web tools, playbooks — anything that we can create that is then HANDS OFF the
   asset itself and becomes part of our operation's money-making ecosystem. we need this to be a
   passive income machine."*
   **Root cause of the violation, recorded so it does not repeat:** this step contradicted the
   standing `canon-passive-assets-over-gig-labor` rule, and the dispatcher executed the checklist
   instead of noticing the conflict. Canon outranks this file. If any duty text here ever conflicts
   with canon, canon wins and the conflict gets logged, not executed.
   **What replaces it:** nothing proactive on any gig marketplace. Time that would have gone to
   proposals goes to building or improving a sellable asset (a product, tool, playbook, or the
   funnel that sells one). Every lane's daily offense is asset velocity, not bidding.
   **Superseded 2026-07-27**: step 3 no longer "stays" even as fulfillment-only — the lane itself is
   sunset, so there is no standing Upwork fulfillment duty at all now, direct requests only (see
   item 3 above).

## The Two-Hour Source Desk — standing SLA, added 2026-07-26

A real, live, pitched offer to journalists (`/two-hour-source-desk/`, ventures/agentready/free-checker):
send a premise to alexander.k.eliot@gmail.com with subject "Two-Hour Source Desk," and this
operation returns real data — real numbers, real screenshots where useful, honest framing of what
the data does and doesn't show — within two hours. If the premise dies, they hear that in the same
two hours, not after they've already pitched their editor. This has been pitched directly to at
least one real reporter (Beatrice Nolan, Fortune, 2026-07-26). It needs an actual monitor, not just
a page — this section is that monitor's contract.

**The scheduled task**: `ake-source-desk-monitor`, cron `*/30 * * * *` (every 30 minutes — frequent
enough to service any request well inside the 2-hour promise, matching the existing precedent of
`ake-main-session-sync-window`'s 45-minute cadence). Full prompt lives in the task's own SKILL.md;
summarized here so any session can rebuild it from this file alone if it's ever lost:

1. Check the studio Gmail inbox (authenticated claude-in-chrome, not the sandboxed browser) for any
   message with "Two-Hour Source Desk" in the subject that isn't already logged in
   `ventures/herald/source-desk-log.md` as ANSWERED or DECLINED.
2. **New request found**: log it immediately in `source-desk-log.md` with the real received
   timestamp, status ⏳ IN PROGRESS, and the verbatim premise. This starts the visible clock.
3. Actually do the check the premise asks for, using this operation's real tools (audit.js, the
   probe protocols in `ventures/local/` and `ventures/herald/2am-test/`, live browser verification,
   whatever fits) — never simulate or predict what a check would show. If a premise cannot be
   honestly serviced (see the decline criteria in `source-desk-log.md`), say so plainly instead of
   forcing an answer.
4. Reply to the sender directly from the studio Gmail with the real finding: numbers, dates,
   sources, and — critically — an honest statement of the limits of what was checked. A finding
   that kills the reporter's premise is exactly as valid a deliverable as one that supports it.
5. Update `source-desk-log.md`: ✅ ANSWERED with the real elapsed time, or ⚠️ MISSED SLA with the
   honest reason if the two-hour window was blown — never silently mark late work as on-time.
6. If nothing new is pending, log nothing (an empty check is not a receipt-worthy event) and exit
   with minimal token spend — this duty must stay cheap on every cycle that finds no new request.
7. If a request is already ⏳ IN PROGRESS and closing in on the 2-hour mark with the work not done,
   escalate to `ops/the operator-tasks.md` rather than let the SLA lapse silently.

**Standing constraint**: this monitor never fabricates a "sent, no bounces expected" style claim.
Every reply must be verified sent from the real Sent folder before the log entry is marked ANSWERED,
same discipline as every other press-facing action in this operation.

## REVIVAL PROCEDURE (new session after death)
1. Read this file + ops/agents.md + ops/scoreboard.md tail.
2. CronList; recreate any missing job from the table above using the universal pattern (per-lane specifics live in each charter).
3. Run the daily duty immediately if >24h since last scoreboard entry.
4. Note: session crons expire in 7 days — recreating them IS the weekly heartbeat duty (STEWARD checks Fridays).
5. **Fleet-wide horizontal-agent check (added 2026-07-24), every dispatcher run, not just on revival**:
   HERALD, GUIDE, and FACTOR are the three fleet-wide agents that own no numbered lane and must
   always have SOME live cadence — either their own dedicated scheduled task (`ake-herald-continuous`,
   `ake-guide-continuous`, `ake-factor-daily`) or, for HERALD only, the dispatcher's own fallback
   duty text below. GUIDE and FACTOR have NO fallback duty text here — if their dedicated task ever
   goes missing or disabled, nothing else picks up their work. Every dispatcher run: check via
   `list_scheduled_tasks` that all three exist and are enabled. If one is missing/disabled, that is
   a real gap, not routine variance — log it plainly to `ops/the operator-tasks.md` and either re-enable
   it (if it still exists, just disabled) or recreate it from this file's own record of its last-known
   prompt (check git history on `/Users/bg/.claude/scheduled-tasks/<taskId>/SKILL.md` if needed). Do
   not attempt to run GUIDE's or FACTOR's full mandate inline as a substitute — recreate/re-enable
   the dedicated task instead, since the dispatcher does not carry their full duty logic itself.

## Friday doc-integrity check (added to STEWARD's audit duty, 2026-07-22)
Two silent-drift failures found in one 2026-07-22 audit: the Command Center's auto-sync
placeholders had been quietly overwritten and the build script kept "succeeding" while doing
nothing, and `ops/the operator-tasks.md` carried 4 stale/contradicted items for days unnoticed. Fold
into STEWARD's existing Friday pass: spot-check `ops/the operator-tasks.md`'s open items against 3-4
random lane `state.md` files for contradictions, and confirm `scripts/build-command-center.py`'s
`<!--STAMP-->`/`<!--FEED-->` markers still exist in `ops/command-center-template.html` (if they've
been hand-overwritten again, note it — the script will silently no-op otherwise). Log findings to
scoreboard.md same as any other Friday finding; only escalate to the Operator if something found is
itself the Operator-actionable.

## Standing constraints (survive any session)
FULL AUTHORIZATION DEFAULT (agent-common.md — never ask permission; escalate only physical impossibilities as queue items) · MULTI-AGENT WORKFLOWS FORBIDDEN without explicit per-run the Operator authorization in chat, no session flag (ultracode included) overrides this, no "research-only/no live listing" carve-out either — usage is cost and the #1 shared resource every lane draws from (2026-07-20 hard rule after a 116K-token violation) · fulfillment override absolute · reallocation + shelf-promotion rules in lane-doctrine.md · hard rules in agent-common.md · the Operator = hands only for the physically-impossible list.

## Weekly CEO brief (Mon 9:53) — per ops/policies.md
Write ops/briefs/<date>.md (revenue, signal, kills/promotions, unlock queue, the one decision), surface in chat, commit+push. Max 300 words.

## Monthly benchmark re-run duty (1st of month, folded into that day's dispatcher run)
Every published benchmark makes an explicit "we re-audit these periodically" promise (the
subscribe CTA on every benchmark page and the homepage says so). Keep that promise real:
1. **SaaS benchmark**: `ventures/agentready/benchmark/run_benchmark.sh` re-runs the real 22-site
   list automatically (bash + audit.js, no browser needed). Diff new scores against
   `ventures/agentready/benchmark/results.jsonl`'s previous run before overwriting it.
2. **Accessibility benchmark**: `ventures/usher/tools/accessibility-benchmark-sites.md` has the
   10-site list and full re-run procedure (needs browser tools, axe-core scans a rendered DOM).
3. **E-commerce, dental, and financial-advisor benchmarks**: NOT YET AUTOMATABLE. Their site
   lists were never saved as a reusable script the way the SaaS one was — the URLs only exist as
   brand names in each page's own HTML table. Before these can join the monthly cadence, a
   session needs to reconstruct and save each site list (same pattern as `run_benchmark.sh`).
   Flagging this honestly rather than silently dropping these three from the cadence.
4. For any benchmark actually re-run: if the average/median moved meaningfully, update that
   page's ranking table and headline stats, update any playbook whose copy cites the old number
   (source markdown AND the live Gumroad description), push, deploy-verify, IndexNow resubmit,
   log the diff to that lane's state.md.
5. If nothing moved meaningfully, still log "re-ran, no material change" — a monthly cadence that
   silently skips a no-change month looks identical to a cadence that never ran at all.

## Dashboard duty (all sessions)
Every operator session ends with: regenerate + republish the Command Center (scripts/build-command-center.py + Artifact tool), so the board always shows the latest state. the Operator's handoffs arrive via ops/the operator-tasks.md — read it every session.
